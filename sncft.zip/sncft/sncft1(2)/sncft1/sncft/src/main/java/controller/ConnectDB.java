package controller;
import java.sql.*;

public class ConnectDB {
	Connection con = null ;
	public Connection open_connection() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://127.0.0.1:3306/sncft";
			String login = "root";
			String password = "aziz2003";
			con = DriverManager.getConnection(url,login,password);
			System.out.print("connected");
			return con;
		}catch(SQLException e) {
			e.printStackTrace();
			return null;
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
    public void close_connection() {
    	try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }
	public ResultSet select_exec(String sql) { 
		
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			return rs;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null ;
	}
	
	public int update_exec( String sql ) {
		try {
			Statement st = con.createStatement();
			int c  = st.executeUpdate(sql);
			return c;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0 ;
	}

}

package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import controller.ConnectDB;

public class Admin {
	private String login;
	private String password;
	public Admin(String login,String password) {
		this.login=login;
		this.password=password;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	static public boolean checkAdminLogin(String login) {
		ConnectDB db=new ConnectDB();
		Connection c  = db.open_connection();
		String sql="select * from admin where login='"+login+"'";
		
		try {
			ResultSet rs=db.select_exec(sql);
			if(rs.next()) {
				return true;
			}
			else {
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	static public boolean checkAdminPassword(String login,String password) {
		ConnectDB db=new ConnectDB();
		Connection c  = db.open_connection();
		String sql="select * from admin where login='"+login+"'";
		try {
			ResultSet rs=db.select_exec(sql);
			if(rs.next()) {
				if(rs.getString("password").equals(password))
					return true;
				else
					return false;
			}
			return false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public static void ajouterTraffic(String depart,String arrive,float prix,int nbBillet) {
		ConnectDB db=new ConnectDB();
		Connection c  = db.open_connection();
		String sql="insert into traffic (depart,arrive,prix,nbBillets) values('"+depart+"','"+arrive+"','"+prix+"','"+nbBillet+"')";
		db.update_exec(sql);
		db.close_connection();
	}
	public static void mofifierTraffic(int id,String depart,String arrive,float prix,int nbBillet) {
		ConnectDB db=new ConnectDB();
		Connection c  = db.open_connection();
		String sql="update traffic set depart='"+depart +"', arrive='"+arrive+"', prix='"+prix +"', nbBillets='"+nbBillet+"'";
		db.update_exec(sql);
		db.close_connection();
	}
	public static void supprimerTraffic(int id) {
		ConnectDB db=new ConnectDB();
		Connection c  = db.open_connection();
		String sql="delete from traffic where id="+id;
		db.update_exec(sql);
		db.close_connection();
	}
	public static void signUp(String username,String password) {
		ConnectDB db=new ConnectDB();
		Connection c  = db.open_connection();
		String sql = "insert into admin (login,password) values ('"+username+"'"+",'"+password+"')";
		db.update_exec(sql);
		db.close_connection();
	}
	
	
}

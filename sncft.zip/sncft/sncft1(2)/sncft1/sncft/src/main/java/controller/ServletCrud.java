package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Admin;

import java.io.IOException;
import java.sql.Connection;

import controller.ConnectDB;
@WebServlet({"/update","/ajout","/delete"})
public class ServletCrud extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String id = request.getParameter("id");
			ConnectDB db = new ConnectDB();
			Connection c  = db.open_connection();
			db.update_exec("delete from traffic where id="+id);
			response.sendRedirect("home.jsp");
			
	}
	
	public void ajout (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String depart = request.getParameter("depart");
		String arrive = request.getParameter("arrive");
		float prix = Float.parseFloat(request.getParameter("prix"));
		int nbBillets = Integer.parseInt(request.getParameter("nbBillets"));
		Admin.ajouterTraffic(depart, arrive, prix,nbBillets);
		response.sendRedirect("home.jsp");
	}
	
	public void modifier (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String id = request.getParameter("id");
		String depart = request.getParameter("depart");
		String arrive = request.getParameter("arrive");
		String prix = request.getParameter("prix");
		String nbBillets = request.getParameter("nbBillets");
		ConnectDB db = new ConnectDB();
		Connection c  = db.open_connection();
		db.update_exec("UPDATE traffic SET depart = '"+depart
			+ "',arrive = '"+arrive
			+ "',prix = "+prix
			+ ",nbBillets = "+nbBillets
			+ " WHERE id ="+id);
		response.sendRedirect("home.jsp");
	}
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getServletPath();
		switch(action){ 
		case "/ajout":
			ajout(request,response);
			break;
		case "/update":
			modifier(request,response);
			break;
		
		}
	}

}

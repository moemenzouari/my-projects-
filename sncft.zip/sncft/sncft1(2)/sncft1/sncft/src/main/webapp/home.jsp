<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@ page import='java.sql.*' %>
<%@ page import='controller.ConnectDB' %>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<style>
.input-group{
margin: 50px;
    width: auto;
}
.form-control{
padding:16px;
}
.table{
margin:50px;
width:94%;
}
.hide{
display:flex;
justify-content:center;
}
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-info-subtle">
<div class="container-fluid">
<div class="collapse navbar-collapse" id="navbarSupportedContent">
<ul class="navbar-nav me-auto mb-2 mb-lg-0">
<li class="nav-item"><a class="nav-link active" class="navbar-brand" href="#"><%=session.getAttribute("username")%></a></li>
<li class="nav-item"><a class="nav-link" href="page4.jsp">ajouter</a></li>
<li class="nav-item"><a class="nav-link" href="Logout">log out</a></li>
</ul>
</div>
</div>
</nav>
<table class="table">
<tr>
<th scope="col">isbn</th>
<th scope="col">auteur</th>
<th scope="col">titre</th>
<th scope="col">annee</th>
<th scope="col">prix</th>
<th scope="col">*</th>
</tr>
<%
ConnectDB db = new ConnectDB();
db.open_connection();
ResultSet rs = db.select_exec("select * from traffic");
while(rs.next()){
%>
	<tr>
	<td><%= rs.getInt("id") %></td>
	<td><%= rs.getString("depart") %></td>
	<td><%= rs.getString("arrive") %></td>
	<td><%= rs.getFloat("prix") %></td>
	<td><%= rs.getInt("nbBillets") %></td>
	<td><a href="delete?id=<%=rs.getInt("id")%>">delete</a></td>
	<td><a href="update.jsp?id=<%=rs.getInt("id")%>">update</a></td>
	<td></td>
	</tr>
	<%
}



%>
</table>
</body>
</html>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Login</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<style>
html{
    height:100%;
}
body{
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 100%;
    font-size:18px;
}
form{
    display: flex;
    flex-direction: column;
    width: 30%;
}
input{
margin:5px;
padding:10px;

}
</style>
</head>
<body>
<%  if (session.getAttribute("username") == null || session.getAttribute("username").equals("")){%>

	<h1>Authentification</h1>
<form action="LoginServlet" method="post">
username: <input class="form-control" type="text" name="username"/>
password: <input class="form-control" type="password" name="password"/>
<input class="btn btn-primary" type="submit"/>
<p>Pas encore inscrit? <a href="./signUp.jsp">Inscrivez vous ici!</a></p>
</form>
	<%
}else{
	response.sendRedirect("home.jsp");
} %>

</body>
</html>
<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<%@ page import='java.sql.*' %>
<%@ page import='controller.ConnectDB' %>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<style>
html{
    height:100%;
}
body{
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    height: 100%;
    font-size:18px;
}
form{
    display: flex;
    flex-direction: column;
    width: 30%;
}
input{
margin:5px;
padding:10px;

}
</style>
</head>
<body>
<form action="update" method="post">

<%
ConnectDB db = new ConnectDB();
db.open_connection();
String id = request.getParameter("id");
ResultSet rs = db.select_exec("select * from traffic where id="+id);
rs.next();
%>
id:<input class="form-control" type="text" value="<%= rs.getInt("id") %>" name="id" />
depart:<input class="form-control" type="text" value="<%= rs.getString("depart") %>" name="depart"/>
arrive:<input class="form-control" type="text" value="<%= rs.getString("arrive") %>" name="arrive"/>
prix:<input class="form-control" type="text" value="<%= rs.getFloat("prix") %>" name="prix"/>
nbBillet:<input class="form-control" type="text" value="<%= rs.getInt("nbBillets") %>" name="nbBillets"/>
<input class="btn btn-primary" type="submit" />
</form>
</body>
</html>
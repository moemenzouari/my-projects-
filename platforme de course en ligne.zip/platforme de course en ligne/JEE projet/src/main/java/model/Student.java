package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Student extends User{
	
	private String username;
	private int phoneNumber;
	private String adress;
	public Student( String email, String password,String username,int phoneNumber,String adress) {
		super( email, password);
		this.adress=adress;
		this.phoneNumber=phoneNumber;
		this.username=username;
		// TODO Auto-generated constructor stub
	}
	public Student( int studentId,String email, String password,String username,int phoneNumber,String adress) {
		super( email, password);
		this.adress=adress;
		this.phoneNumber=phoneNumber;
		this.username=username;
		this.userId=studentId;
		// TODO Auto-generated constructor stub
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAdress() {
		return adress;
	}
	public void setAdress(String adress) {
		this.adress = adress;
	}
	public ResultSet availableCourses() {
		Connection conn=DataBaseConnection.connectToDB();
		String query="SELECT * FROM courses WHERE DATEDIFF(courseDate, NOW()) >= 1;";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ResultSet rs=ps.executeQuery();
			return rs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	public ResultSet searchCourseByName(String name) {
		Connection conn=DataBaseConnection.connectToDB();
		String query="SELECT * FROM courses WHERE courseName LIKE ?";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setString(1, "%"+name+"%");
			ResultSet rs=ps.executeQuery();
			return rs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	public ResultSet myEnrollements() {
		Connection conn=DataBaseConnection.connectToDB();
		String query="SELECT * FROM courses WHERE courseId in (select courseId from enrollments where studentId=?)";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setInt(1, this.getUserId());
			ResultSet rs=ps.executeQuery();
			return rs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	public int cancelEnrollment(int courseId) {
		Connection conn=DataBaseConnection.connectToDB();
		String query="delete from enrollments where courseId=? and studentId=? ";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setInt(1, courseId);
			ps.setInt(2, this.getUserId());
			int res=ps.executeUpdate();
			return res;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	public int enrollToCourse(int courseId) {
		Connection conn=DataBaseConnection.connectToDB();
		String query="INSERT INTO enrollments (courseId, studentId) VALUES(?,?) ";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setInt(1, courseId);
			ps.setInt(2, this.getUserId());
			int res=ps.executeUpdate();
			return res;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	public static int signUp(String email,String password , String username,int phoneNumber, String adress) {
		Connection conn=DataBaseConnection.connectToDB();
		String query="INSERT INTO users (email, password, username, phonenumber, adress, role) VALUES(?,?,?,?,?,?)";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setString(1,email);
			ps.setString(2,password);
			ps.setString(3, username);
			ps.setInt(4, phoneNumber);
			ps.setString(5,adress);
			ps.setString(6, "student");
			int res=ps.executeUpdate();
			return res;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	
}

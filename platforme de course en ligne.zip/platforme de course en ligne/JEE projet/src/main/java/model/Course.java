package model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Course {
	@Override
	public String toString() {
		return "Course [courseId=" + courseId + ", courseName=" + courseName + ", category=" + category + ", seats="
				+ seats + ", courseDate=" + courseDate + ", description=" + description + ", instructor=" + instructor
				+ "]";
	}
	private int courseId;
	private String courseName;
	private String category;
	private int seats;
	private Date courseDate;
	private String description;
	private Instructor instructor;
	public Course(String courseName, String category, int seats, Instructor instructor,Date courseDate , String description) {
		super();
		this.courseName = courseName;
		this.category = category;
		this.seats = seats;
		this.instructor = instructor;
		this.courseDate=courseDate;
		this.description=description;
	}
	public Course(int courseId,String courseName, String category, int seats, Instructor instructor,Date courseDate , String description) {
		super();
		this.courseName = courseName;
		this.category = category;
		this.seats = seats;
		this.instructor = instructor;
		this.courseDate=courseDate;
		this.description=description;
		this.courseId=courseId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getCourseDate() {
		return courseDate;
	}
	public void setCourseDate(Date courseDate) {
		this.courseDate = courseDate;
	}
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getSeats() {
		return seats;
	}
	public void setSeats(int seats) {
		this.seats = seats;
	}
	public Instructor getInstructor() {
		return instructor;
	}
	public void setInstructor(Instructor instructor) {
		this.instructor = instructor;
	}
	public int availableSeats() {
		Connection conn=DataBaseConnection.connectToDB();
		String query="select count(*) from enrollments where courseId=?";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setInt(1, this.getCourseId());
			ResultSet rs = ps.executeQuery();
			int res = 0;
			if(rs.next()) {
				res= rs.getInt(1);
			}
			return this.getSeats()-res ;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	
}

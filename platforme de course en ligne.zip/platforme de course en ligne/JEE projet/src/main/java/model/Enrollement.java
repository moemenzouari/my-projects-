package model;

public class Enrollement {
	private int enrollementId;
	private Student student;
	private Course course;
	public Enrollement(int enrollementId, Student student, Course course) {
		super();
		this.enrollementId = enrollementId;
		this.student = student;
		this.course = course;
	}
	public int getEnrollementId() {
		return enrollementId;
	}
	public void setEnrollementId(int enrollementId) {
		this.enrollementId = enrollementId;
	}
	public Student getStudent() {
		return student;
	}
	public void setStudent(Student student) {
		this.student = student;
	}
	public Course getCourse() {
		return course;
	}
	public void setCourse(Course course) {
		this.course = course;
	}
	
}

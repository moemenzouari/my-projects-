package model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Instructor extends User{
	private String username;
	private int phoneNumber;
	private String adress;
	public Instructor( String email, String password,String username,int phoneNumber,String adress) {
		super(email,password);
		this.adress=adress;
		this.phoneNumber=phoneNumber;
		this.username=username;
		// TODO Auto-generated constructor stub
	}
	public Instructor( int instructorId,String email, String password,String username,int phoneNumber,String adress) {
		super(email,password);
		this.adress=adress;
		this.phoneNumber=phoneNumber;
		this.username=username;
		this.userId=instructorId;
		// TODO Auto-generated constructor stub
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getAdress() {
		return adress;
	}
	public void setAdress(String adress) {
		this.adress = adress;
	}
	public int addCourse(String courseName,String category, int seats,Date courseDate, String description,
	Instructor instructor) {
		Connection conn=DataBaseConnection.connectToDB();
		String query="INSERT INTO courses (courseName, category, seats, instructorId, courseDate, description) VALUES(?,?,?,?,?,?)";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setString(1,courseName);
			ps.setString(2,category);
			ps.setInt(3, seats);
			ps.setDate(5, courseDate);
			ps.setString(6,description);
			ps.setInt(4, this.getUserId());
			int res=ps.executeUpdate();
			return res;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	public int updateCourse(int courseId,String courseName,String category, int seats,Date courseDate, String description,
	Instructor instructor) {
		Connection conn=DataBaseConnection.connectToDB();
		String query="update courses set courseName=? , category=? , seats=? , courseDate=? , description=? , instructorId=? where courseId=?"  ;
		
		try {
			PreparedStatement ps=conn.prepareStatement(query);
				
			ps.setString(1,courseName);
			ps.setString(2,category);
			ps.setInt(3, seats);
			ps.setDate(4, courseDate);
			ps.setString(5,description);
			ps.setInt(6, this.getUserId());
			ps.setInt(7, courseId);
			int res=ps.executeUpdate();
			return res;
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	public int deleteCourse(int courseId) {
		Connection conn=DataBaseConnection.connectToDB();
		String query="delete from courses where courseId=?";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setInt(1,courseId);
			int res = ps.executeUpdate();
			return res;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	public ResultSet listInstructorCourses() {
		Connection conn=DataBaseConnection.connectToDB();
		String query="select * from courses where instructorId=?";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setInt(1, this.getUserId());
			ResultSet rs=ps.executeQuery();
			return rs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
}

package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public abstract class  User {
	protected int userId;
	private String email;
	private String password;
	public User( String email, String password) {
		super();
		this.email = email;
		this.password = password;
	}
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public static ResultSet login(String email, String password) {
		Connection conn= DataBaseConnection.connectToDB();
		String query = "select * from users where email=? and password=?";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setString(1, email);
			ps.setString(2, password);
			ResultSet rs=ps.executeQuery();
			return rs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
	}
	public static ResultSet userByEmail(String email) {
		Connection conn=DataBaseConnection.connectToDB();
		String query="SELECT * FROM users WHERE email=?";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setString(1, email);
			ResultSet rs=ps.executeQuery();
			return rs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
}

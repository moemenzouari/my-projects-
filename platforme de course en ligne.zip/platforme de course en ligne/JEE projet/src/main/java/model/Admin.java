package model;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Admin extends User{

	public Admin( String email, String password) {
		super( email, password);
		// TODO Auto-generated constructor stub
	}
	public int addCourse(String courseName,String category, int seats,Date courseDate, String description,
	 Instructor instructor) {
		Connection conn=DataBaseConnection.connectToDB();
		String query="INSERT INTO courses (courseName, category, seats, instructorId, courseDate, description) VALUES(?,?,?,?,?,?)";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setString(1,courseName);
			ps.setString(2,category);
			ps.setInt(3, seats);
			ps.setDate(5, courseDate);
			ps.setString(6,description);
			ps.setInt(4, instructor.getUserId());
			int res=ps.executeUpdate();
			return res;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	public int updateCourse(int courseId,String courseName,String category, int seats,Date courseDate, String description,
			 Instructor instructor) {
		Connection conn=DataBaseConnection.connectToDB();
		String query="update courses set courseName=? , category=? , seats=? , courseDate=? , description=? , instructorId=? where courseId=?"  ;
		
		try {
			PreparedStatement ps=conn.prepareStatement(query);
				
			ps.setString(1,courseName);
			ps.setString(2,category);
			ps.setInt(3, seats);
			ps.setDate(4, courseDate);
			ps.setString(5,description);
			ps.setInt(6, instructor.getUserId());
			ps.setInt(7, courseId);
			int res=ps.executeUpdate();
			return res;
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	public int deleteCourse(int courseId) {
		Connection conn=DataBaseConnection.connectToDB();
		String query="delete from courses where courseId=?";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setInt(1,courseId);
			int res = ps.executeUpdate();
			return res;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	public int addInstructor(String email,String password,String username, int phoneNumber,String adress) {
		Connection conn=DataBaseConnection.connectToDB();
		String query="INSERT INTO users (email, password, username, phonenumber, adress, role) VALUES(?,?,?,?,?,?)";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setString(1,email);
			ps.setString(2,password);
			ps.setString(3, username);
			ps.setInt(4, phoneNumber);
			ps.setString(5,adress);
			ps.setString(6, "instructor");
			int res=ps.executeUpdate();
			return res;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
		
	}
	public int updateInstructor(int instructorId,String email,String password,String username, int phoneNumber,String adress) {
		Connection conn=DataBaseConnection.connectToDB();
		String query="update users set email=? , password=? , username=? , phoneNumber=? , adress=? where userId=?"  ;
		
		try {
			PreparedStatement ps=conn.prepareStatement(query);
				
			ps.setString(1,email);
			ps.setString(2,password);
			ps.setString(3, username);
			ps.setInt(4, phoneNumber);
			ps.setString(5,adress);
			ps.setInt(6, instructorId);
			int res=ps.executeUpdate();
			return res;
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	public int deleteInstructor(int instructorId) {
		Connection conn=DataBaseConnection.connectToDB();
		String query="delete from users where userId=?";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setInt(1,instructorId);
			int res = ps.executeUpdate();
			return res;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
	}
	public ResultSet coursesList() {
		Connection conn=DataBaseConnection.connectToDB();
		String query="select * from courses";
		try {
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);
			return rs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	public ResultSet instructorList() {
		Connection conn=DataBaseConnection.connectToDB();
		String query="select * from users where role=?";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setString(1,"instructor");
			ResultSet rs = ps.executeQuery();
			return rs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	public static ResultSet instructorById(int instructorId) {
		Connection conn=DataBaseConnection.connectToDB();
		String query="select * from users where userId=?";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setInt(1, instructorId);
			ResultSet rs = ps.executeQuery();
			return rs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	// adding method course by Id later
	public static ResultSet courseById(int courseId) {
		Connection conn=DataBaseConnection.connectToDB();
		String query="select * from courses where courseId=?";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setInt(1, courseId);
			ResultSet rs = ps.executeQuery();
			return rs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
}

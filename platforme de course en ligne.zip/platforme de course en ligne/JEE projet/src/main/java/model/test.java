package model;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection conn=DataBaseConnection.connectToDB();
		if(conn!=null) {
			System.out.println("connected");
		}
		else {
			System.out.println("not connected");
		}
		ResultSet rs=User.userByEmail("prof.jones@example.com");
		
    	Student student=null;
    	Instructor instructor=null;
    	try {
			if(rs.next()) {
				instructor = new Instructor(rs.getInt("userId"),rs.getString("email"),rs.getString("password"),rs.getString("username"),rs.getInt("phonenumber"),rs.getString("adress"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        ArrayList<Course> courses=new ArrayList<Course>() ;
        ResultSet rs2= instructor.listInstructorCourses();
        try {
			while(rs2.next()) {
				Date courseDate=rs2.getDate("courseDate");
				courses.add(new Course(rs2.getInt("courseId"),rs2.getString("courseName"),rs2.getString("category"),rs2.getInt("seats"),instructor,courseDate,rs2.getString("description")));
			}
			System.out.println(courses);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	

}

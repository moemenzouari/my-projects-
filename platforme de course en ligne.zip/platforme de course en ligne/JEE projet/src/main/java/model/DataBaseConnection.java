package model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DataBaseConnection {
	static String url = "jdbc:mysql://localhost:3306/online_course_database"; // Change database name
	static String user = "root"; // Change to your username
	static String password = "zouari30042003"; // Change to your password

	public static Connection connectToDB() {
        // Database credentials
        
        // Connection object
        Connection conn = null;

        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            conn = DriverManager.getConnection(url, user, password);
            System.out.println("Connected to the database!");

            // Execute a sample query
//            Statement stmt = conn.createStatement();
//            ResultSet rs = stmt.executeQuery("SELECT * FROM personne"); // Change table name
//
//            while (rs.next()) {
//                System.out.println("ID: " + rs.getInt("id") + ", Name: " + rs.getString("nom"));
//            }
//
//            // Close resources
//            rs.close();
//            stmt.close();
//            conn.close();
        } catch (ClassNotFoundException e) {
            System.out.println("JDBC Driver not found!");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Database connection failed!");
            e.printStackTrace();
        }
		return conn;
    }
}

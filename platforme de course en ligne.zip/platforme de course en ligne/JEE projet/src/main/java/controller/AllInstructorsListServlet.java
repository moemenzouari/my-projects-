package controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Admin;
import model.Instructor;

/**
 * Servlet implementation class AllInstructorsListServlet
 */
@WebServlet("/AllInstructorsListServlet")
public class AllInstructorsListServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Fetch all courses from the database
    	HttpSession session=request.getSession(false);
    	if (session == null || session.getAttribute("password") == null || session.getAttribute("email") == null) {
            // Redirect to login page if no session or user is found
            response.sendRedirect("login.jsp");
            return;
        }
    	String email=(String)session.getAttribute("email");
    	String password=(String)session.getAttribute("password");
    	Admin admin = new Admin(email,password);
        ArrayList<Instructor> instructors=new ArrayList<Instructor>() ;
        ResultSet rs= admin.instructorList();
        try {
			while(rs.next()) {
				Instructor instructor = new Instructor(rs.getInt("userId"),rs.getString("email"),rs.getString("password"),rs.getString("username"),rs.getInt("phonenumber"),rs.getString("adress"));
				instructors.add(instructor);
			}
			request.setAttribute("instructors", instructors);
	        // Forward to the admin_instructors.jsp page
	        RequestDispatcher dispatcher = request.getRequestDispatcher("admin_instructors_list.jsp");
	        dispatcher.forward(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        // Set the courses as a request attribute
        request.setAttribute("instructors", instructors);
        // Forward to the admin_instructors.jsp page
        RequestDispatcher dispatcher = request.getRequestDispatcher("admin_instructors_list.jsp");
        dispatcher.forward(request, response);
    }
	
}

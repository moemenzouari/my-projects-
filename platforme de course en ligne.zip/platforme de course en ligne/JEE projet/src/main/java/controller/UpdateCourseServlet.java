package controller;

import java.io.IOException;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Admin;
import model.Course;
import model.Instructor;

/**
 * Servlet implementation class UpdateCourseServlet
 */
@WebServlet("/UpdateCourseServlet")
public class UpdateCourseServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession(false);
    	if (session == null || session.getAttribute("password") == null || session.getAttribute("email") == null) {
            // Redirect to login page if no session or user is found
            response.sendRedirect("login.jsp");
            return;
        }
		
    	String email=(String)session.getAttribute("email");
    	String password=(String)session.getAttribute("password");
    	Admin admin = new Admin(email,password);
    	
        int courseId = Integer.parseInt(request.getParameter("courseId"));
        String courseName = request.getParameter("courseName");
        String category = request.getParameter("category");
        int seats = Integer.parseInt(request.getParameter("seats"));
        int instructorId = Integer.parseInt(request.getParameter("instructorId"));
        Date courseDate = Date.valueOf(request.getParameter("courseDate"));
        String description = request.getParameter("description");

        // Update the course in the database
        try {
            
            ResultSet rs= admin.instructorById(instructorId);
            if(rs.next()) {
            	Instructor instructor = new Instructor(rs.getInt("userId"),rs.getString("email"),rs.getString("password"),rs.getString("username"),rs.getInt("phoneNumber"),rs.getString("adress"));
            	int res = admin.updateCourse(courseId,courseName, category, seats, courseDate, description, instructor);
            	if (res==1) {
                    // Set success message
                    request.setAttribute("message", "Course updated succefully");
                    request.setAttribute("messageType", "success");
                } else {
                    // Set error message
                    request.setAttribute("message", "Failed to update course.");
                    request.setAttribute("messageType", "error");
                }

                // Forward to the course list page
                RequestDispatcher dispatcher = request.getRequestDispatcher("AllCoursesList");
                dispatcher.forward(request, response);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	HttpSession session=request.getSession(false);
    	if (session == null || session.getAttribute("password") == null || session.getAttribute("email") == null) {
            // Redirect to login page if no session or user is found
            response.sendRedirect("login.jsp");
            return;
        }
		
    	String email=(String)session.getAttribute("email");
    	String password=(String)session.getAttribute("password");
    	Admin admin = new Admin(email,password);
        int courseId = Integer.parseInt(request.getParameter("courseId"));

        // Fetch the course details from the database
        ResultSet rs= admin.courseById(courseId);
        try {
			if(rs.next()) {
				ResultSet rs2= admin.instructorById(rs.getInt("instructorId"));
			    if(rs2.next()) {
			    	Instructor instructor = new Instructor(rs2.getInt("userId"),rs2.getString("email"),rs2.getString("password"),rs2.getString("username"),rs2.getInt("phoneNumber"),rs2.getString("adress"));
			    	Course course=new Course(rs.getInt("courseId"),rs.getString("courseName"),rs.getString("category"),rs.getInt("seats"),instructor,rs.getDate("courseDate"),rs.getString("description"));
			    	request.setAttribute("course", course);
			    }	
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        // Set the course as a request attribute
        

        // Forward to the edit_course.jsp page
        RequestDispatcher dispatcher = request.getRequestDispatcher("admin_edit_course.jsp");
        dispatcher.forward(request, response);
    }
	

}

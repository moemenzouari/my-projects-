package controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Admin;
import model.Student;
import model.User;

/**
 * Servlet implementation class EnrollServlet
 */
@WebServlet("/EnrollServlet")
public class EnrollServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	HttpSession session=request.getSession(false);
    	if (session == null || session.getAttribute("password") == null || session.getAttribute("email") == null) {
            // Redirect to login page if no session or user is found
            response.sendRedirect("login.jsp");
            return;
        }

       
        String email=(String)session.getAttribute("email");
    	String password=(String)session.getAttribute("password");
    	
    	ResultSet rs=User.userByEmail(email);
    	Student student=null;
    	int courseId = Integer.parseInt(request.getParameter("courseId"));
    	try {
			if(rs.next()) {
				student = new Student(rs.getInt("userId"),rs.getString("email"),rs.getString("password"),rs.getString("username"),rs.getInt("phoneNumber"),rs.getString("adress"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        // Check if the student is already enrolled in the course
        
//        if () {
//            response.sendRedirect("student/student_home.jsp?error=already_enrolled");
//            return;
//        }

        // Enroll the student in the course
    	int res = student.enrollToCourse(courseId);
    	
    	if (res==1) {
            // Set success message
            request.setAttribute("message", "enrolled to the course successfully!");
            request.setAttribute("messageType", "success");
        } else {
            // Set error message
            request.setAttribute("message", "Failed to enroll to the course.");
            request.setAttribute("messageType", "error");
        }

        // Forward to the course list page
        RequestDispatcher dispatcher = request.getRequestDispatcher("StudentHomeServlet");
        dispatcher.forward(request, response);
    }
}

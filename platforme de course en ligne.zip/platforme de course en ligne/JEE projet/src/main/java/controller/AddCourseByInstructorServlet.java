package controller;

import java.io.IOException;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Admin;
import model.Course;
import model.Instructor;
import model.User;

/**
 * Servlet implementation class AddCourseByInstructorServlet
 */
@WebServlet("/AddCourseByInstructorServlet")
public class AddCourseByInstructorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Fetch all courses from the database
    	HttpSession session=request.getSession(false);
    	if (session == null || session.getAttribute("password") == null || session.getAttribute("email") == null) {
            // Redirect to login page if no session or user is found
            response.sendRedirect("login.jsp");
            return;
        }
    	String email=(String)session.getAttribute("email");
    	String password=(String)session.getAttribute("password");
    	String courseName = request.getParameter("courseName");
        String category = request.getParameter("category");
        int seats = Integer.parseInt(request.getParameter("seats"));
        
        Date courseDate = Date.valueOf(request.getParameter("courseDate"));
        String description = request.getParameter("description");
        Date currentDate = new Date(System.currentTimeMillis());
        if (courseDate.before(currentDate)) {
            request.setAttribute("message", "The course date must be greater than today's date.");
            request.setAttribute("messageType", "error");
            RequestDispatcher dispatcher = request.getRequestDispatcher("instructor_add_course.jsp");
            dispatcher.forward(request, response);
            return;
        }
        if (seats>30) {
        	request.setAttribute("message", "The maximum number of seats is 30 ");
            request.setAttribute("messageType", "error");
            RequestDispatcher dispatcher = request.getRequestDispatcher("instructor_add_course.jsp");
            dispatcher.forward(request, response);
            return;
        }
        
    	ResultSet rs=User.userByEmail(email);
    	Instructor instructor=null;
    	try {
			if(rs.next()) {
				instructor = new Instructor(rs.getInt("userId"),rs.getString("email"),rs.getString("password"),rs.getString("username"),rs.getInt("phonenumber"),rs.getString("adress"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	int res = instructor.addCourse(courseName, category, seats, courseDate, description, instructor);
    	if (res==1) {
            // Set success message
            request.setAttribute("message", "Course added successfully!");
            request.setAttribute("messageType", "success");
        } else {
            // Set error message
            request.setAttribute("message", "Failed to add course.");
            request.setAttribute("messageType", "error");
        }

        // Forward to the course list page
        RequestDispatcher dispatcher = request.getRequestDispatcher("InstructorHomeServlet");
        dispatcher.forward(request, response);
    }

}

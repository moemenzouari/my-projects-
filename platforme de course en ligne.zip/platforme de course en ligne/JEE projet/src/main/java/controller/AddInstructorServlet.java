package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Admin;

/**
 * Servlet implementation class AddInstructorServlet
 */
@WebServlet("/AddInstructorServlet")
public class AddInstructorServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve session attributes
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("email") == null || session.getAttribute("password") == null) {
            response.sendRedirect("login.jsp");
            return;
        }
        
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String username = request.getParameter("username");
        int phoneNumber = Integer.parseInt(request.getParameter("phoneNumber"));
        String address = request.getParameter("address");

        // Create an Admin instance
        String adminEmail = (String) session.getAttribute("email");
        String adminPassword = (String) session.getAttribute("password");
        Admin admin = new Admin(adminEmail, adminPassword);

        // Add the instructor
        int result = admin.addInstructor(email, password, username, phoneNumber, address);

        // Set success or error message
        if (result > 0) {
            request.setAttribute("message", "Instructor added successfully!");
            request.setAttribute("messageType", "success");
        } else {
            request.setAttribute("message", "Failed to add instructor.");
            request.setAttribute("messageType", "error");
        }

        // Forward back to the admin page
        request.getRequestDispatcher("add_instructor.jsp").forward(request, response);
    }
}

package controller;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Admin;
import model.Course;
import model.Instructor;

/**
 * Servlet implementation class AllCoursesList
 */
@WebServlet("/AllCoursesList")
public class AllCoursesListServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Fetch all courses from the database
    	HttpSession session=request.getSession(false);
    	if (session == null || session.getAttribute("password") == null || session.getAttribute("email") == null) {
            // Redirect to login page if no session or user is found
            response.sendRedirect("login.jsp");
            return;
        }
    	String email=(String)session.getAttribute("email");
    	String password=(String)session.getAttribute("password");
    	Admin admin = new Admin(email,password);
        ArrayList<Course> courses = new ArrayList<Course>() ;
        
        
		try {
			ResultSet rs= admin.coursesList();
			while(rs.next()) {
				Date courseDate=rs.getDate("courseDate");
				ResultSet rs2= Admin.instructorById(rs.getInt("instructorId"));
				rs2.next();
				Instructor instructor = new Instructor(rs2.getInt("userId"),rs2.getString("email"),rs2.getString("password"),rs2.getString("username"),rs2.getInt("phonenumber"),rs2.getString("adress"));
				courses.add(new Course(rs.getInt("courseId"),rs.getString("courseName"),rs.getString("category"),rs.getInt("seats"),instructor,courseDate,rs.getString("description")));
				// Set the courses as a request attribute   
			}
			request.setAttribute("message", request.getAttribute("message"));
            request.setAttribute("messageType", request.getAttribute("messageType"));
			request.setAttribute("courses", courses);
		    // Forward to the admin_courses.jsp page
		    RequestDispatcher dispatcher = request.getRequestDispatcher("admin_courses_list.jsp");
		    dispatcher.forward(request, response);
		} catch (SQLException | ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	HttpSession session=request.getSession(false);
    	if (session == null || session.getAttribute("password") == null || session.getAttribute("email") == null) {
            // Redirect to login page if no session or user is found
            response.sendRedirect("login.jsp");
            return;
        }
    	String email=(String)session.getAttribute("email");
    	String password=(String)session.getAttribute("password");
    	Admin admin = new Admin(email,password);
        ArrayList<Course> courses = new ArrayList<Course>() ;
        
        
		try {
			ResultSet rs= admin.coursesList();
			while(rs.next()) {
				Date courseDate=rs.getDate("courseDate");
				ResultSet rs2= Admin.instructorById(rs.getInt("instructorId"));
				rs2.next();
				Instructor instructor = new Instructor(rs2.getInt("userId"),rs2.getString("email"),rs2.getString("password"),rs2.getString("username"),rs2.getInt("phonenumber"),rs2.getString("adress"));
				courses.add(new Course(rs.getInt("courseId"),rs.getString("courseName"),rs.getString("category"),rs.getInt("seats"),instructor,courseDate,rs.getString("description")));
				// Set the courses as a request attribute   
			}
			request.setAttribute("message", request.getAttribute("message"));
            request.setAttribute("messageType", request.getAttribute("messageType"));
			request.setAttribute("courses", courses);
		    // Forward to the admin_courses.jsp page
		    RequestDispatcher dispatcher = request.getRequestDispatcher("admin_courses_list.jsp");
		    dispatcher.forward(request, response);
		} catch (SQLException | ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}

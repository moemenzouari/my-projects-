package controller;

import java.io.IOException;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Admin;
import model.Course;
import model.Student;
import model.User;

/**
 * Servlet implementation class CancelEnrollmentServlet
 */
@WebServlet("/CancelEnrollmentServlet")
public class CancelEnrollmentServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	HttpSession session=request.getSession(false);
    	if (session == null || session.getAttribute("password") == null || session.getAttribute("email") == null) {
            // Redirect to login page if no session or user is found
            response.sendRedirect("login.jsp");
            return;
        }
        String email=(String)session.getAttribute("email");
    	String password=(String)session.getAttribute("password");
    	Date currentDate = new Date(System.currentTimeMillis());
    	ResultSet rs=User.userByEmail(email);
    	Student student=null;
    	int courseId = Integer.parseInt(request.getParameter("courseId"));
    	try {
			if(rs.next()) {
				student = new Student(rs.getInt("userId"),rs.getString("email"),rs.getString("password"),rs.getString("username"),rs.getInt("phoneNumber"),rs.getString("adress"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	ResultSet rs2 = Admin.courseById(courseId);
    	try {
			if(rs2.next()) {
				long currentTimeMillis = System.currentTimeMillis();
	            long courseDateTimeMillis = rs2.getDate("courseDate").getTime();
	            long timeDifferenceHours = (courseDateTimeMillis - currentTimeMillis) / (1000 * 60 * 60);
	            if(timeDifferenceHours<24 ) {
	            	request.setAttribute("message", "Cannot cancel enrollment before 24 hours or less of the course  ");
	                request.setAttribute("messageType", "error");
	            }
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        int res = student.cancelEnrollment(courseId);
        if (res==1) {
            // Set success message
            request.setAttribute("message", "enrollment canceled ");
            request.setAttribute("messageType", "success");
        } else {
            // Set error message
            request.setAttribute("message", "Cannot cancel enrollment ");
            request.setAttribute("messageType", "error");
        }
        RequestDispatcher dispatcher = request.getRequestDispatcher("StudentEnrollmentsServlet");
        dispatcher.forward(request, response);
    }
}

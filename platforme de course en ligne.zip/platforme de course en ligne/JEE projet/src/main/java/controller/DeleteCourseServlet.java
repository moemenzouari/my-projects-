package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Admin;

/**
 * Servlet implementation class DeleteCourseServlet
 */
@WebServlet("/DeleteCourseServlet")
public class DeleteCourseServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	HttpSession session=request.getSession(false);
    	if (session == null || session.getAttribute("password") == null || session.getAttribute("email") == null) {
            // Redirect to login page if no session or user is found
            response.sendRedirect("login.jsp");
            return;
        }
		
    	String email=(String)session.getAttribute("email");
    	String password=(String)session.getAttribute("password");
    	Admin admin = new Admin(email,password);
    	
        int courseId = Integer.parseInt(request.getParameter("courseId"));

        // Delete the course from the database
        int res = admin.deleteCourse(courseId);
        if (res==1) {
            // Set success message
            request.setAttribute("message", "Course deleted succefully");
            request.setAttribute("messageType", "success");
        } else {
            // Set error message
            request.setAttribute("message", "Failed to delete course.");
            request.setAttribute("messageType", "error");
        }

        // Forward to the course list page
        RequestDispatcher dispatcher = request.getRequestDispatcher("AllCoursesList");
        dispatcher.forward(request, response);
    }
}

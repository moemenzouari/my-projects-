package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Admin;

/**
 * Servlet implementation class DeleteInstructorServlet
 */
@WebServlet("/DeleteInstructorServlet")
public class DeleteInstructorServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve session attributes
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("email") == null || session.getAttribute("password") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int instructorId = Integer.parseInt(request.getParameter("userId"));

        // Create an Admin instance
        String adminEmail = (String) session.getAttribute("email");
        String adminPassword = (String) session.getAttribute("password");
        Admin admin = new Admin(adminEmail, adminPassword);

        // Delete the instructor
        int result = admin.deleteInstructor(instructorId);

        // Set success or error message
        if (result > 0) {
            request.setAttribute("message", "Instructor deleted successfully!");
            request.setAttribute("messageType", "success");
        } else {
            request.setAttribute("message", "Failed to delete instructor.");
            request.setAttribute("messageType", "error");
        }

        // Forward back to the admin page
        request.getRequestDispatcher("AllInstructorsListServlet").forward(request, response);
    }
}

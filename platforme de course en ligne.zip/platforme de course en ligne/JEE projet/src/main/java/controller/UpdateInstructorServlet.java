package controller;

import java.io.IOException;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Admin;

/**
 * Servlet implementation class UpdateInstructorServlet
 */
@WebServlet("/UpdateInstructorServlet")
public class UpdateInstructorServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve session attributes
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("email") == null || session.getAttribute("password") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int instructorId = Integer.parseInt(request.getParameter("instructorId"));
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String username = request.getParameter("username");
        int phoneNumber = Integer.parseInt(request.getParameter("phoneNumber"));
        String address = request.getParameter("address");

        // Create an Admin instance
        String adminEmail = (String) session.getAttribute("email");
        String adminPassword = (String) session.getAttribute("password");
        Admin admin = new Admin(adminEmail, adminPassword);

        // Update the instructor
        int result = admin.updateInstructor(instructorId, email, password, username, phoneNumber, address);

        // Set success or error message
        if (result > 0) {
            request.setAttribute("message", "Instructor updated successfully!");
            request.setAttribute("messageType", "success");
        } else {
            request.setAttribute("message", "Failed to update instructor.");
            request.setAttribute("messageType", "error");
        }

        // Forward back to the admin page
        request.getRequestDispatcher("update_instructor.jsp").forward(request, response);
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve session attributes
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("email") == null || session.getAttribute("password") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int instructorId = Integer.parseInt(request.getParameter("userId"));

        // Fetch instructor details
        ResultSet rs = Admin.instructorById(instructorId);
        request.setAttribute("instructorData", rs);

        // Forward to the edit page
        RequestDispatcher dispatcher = request.getRequestDispatcher("update_instructor.jsp");
        dispatcher.forward(request, response);
    }
}

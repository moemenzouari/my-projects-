package controller;

import java.io.IOException;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Admin;
import model.Course;
import model.Instructor;
import model.Student;
import model.User;

/**
 * Servlet implementation class StudentEnrollmentsServlet
 */
@WebServlet("/StudentEnrollmentsServlet")
public class StudentEnrollmentsServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	HttpSession session=request.getSession(false);
    	if (session == null || session.getAttribute("password") == null || session.getAttribute("email") == null) {
            // Redirect to login page if no session or user is found
            response.sendRedirect("login.jsp");
            return;
        }
        String email=(String)session.getAttribute("email");
    	String password=(String)session.getAttribute("password");
    	
    	ResultSet rs=User.userByEmail(email);
    	Student student=null;
    	try {
			if(rs.next()) {
				student = new Student(rs.getInt("userId"),rs.getString("email"),rs.getString("password"),rs.getString("username"),rs.getInt("phoneNumber"),rs.getString("adress"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        // Fetch all enrollments for the student
    	ResultSet rs2 = student.myEnrollements();
    	ArrayList<Course> enrollments = new ArrayList<Course>();
    	try {
			while(rs2.next()) {
				ResultSet rs3= Admin.instructorById(rs2.getInt("instructorId"));
				rs3.next();
				Instructor instructor = new Instructor(rs3.getInt("userId"),rs3.getString("email"),rs3.getString("password"),rs3.getString("username"),rs3.getInt("phonenumber"),rs3.getString("adress"));
				enrollments.add(new Course(
						rs2.getInt("courseId"),
						rs2.getString("courseName"),
						rs2.getString("category"),
						rs2.getInt("seats"),
						instructor,
						rs2.getDate("courseDate"),
						rs2.getString("description")
						));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        // Set the enrollments as a request attribute
    	request.setAttribute("enrollments", enrollments);


        // Forward to the student_enrollments.jsp page
        RequestDispatcher dispatcher = request.getRequestDispatcher("student_enrollments.jsp");
        dispatcher.forward(request, response);
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	HttpSession session=request.getSession(false);
    	if (session == null || session.getAttribute("password") == null || session.getAttribute("email") == null) {
            // Redirect to login page if no session or user is found
            response.sendRedirect("login.jsp");
            return;
        }
        String email=(String)session.getAttribute("email");
    	String password=(String)session.getAttribute("password");
    	
    	ResultSet rs=User.userByEmail(email);
    	Student student=null;
    	try {
			if(rs.next()) {
				student = new Student(rs.getInt("userId"),rs.getString("email"),rs.getString("password"),rs.getString("username"),rs.getInt("phoneNumber"),rs.getString("adress"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        // Fetch all enrollments for the student
    	ResultSet rs2 = student.myEnrollements();
    	ArrayList<Course> enrollments = new ArrayList<Course>();
    	try {
			while(rs2.next()) {
				ResultSet rs3= Admin.instructorById(rs2.getInt("instructorId"));
				rs3.next();
				Instructor instructor = new Instructor(rs3.getInt("userId"),rs3.getString("email"),rs3.getString("password"),rs3.getString("username"),rs3.getInt("phonenumber"),rs3.getString("adress"));
				Course course = new Course(
						rs2.getInt("courseId"),
						rs2.getString("courseName"),
						rs2.getString("category"),
						rs2.getInt("seats"),
						instructor,
						rs2.getDate("courseDate"),
						rs2.getString("description")
						);
				Date currentDate = new Date(System.currentTimeMillis());
				if(currentDate.before(course.getCourseDate())) {
					enrollments.add(course);
				}
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        // Set the enrollments as a request attribute
    	request.setAttribute("enrollments", enrollments);
    	request.setAttribute("message", request.getAttribute("message"));
        request.setAttribute("messageType", request.getAttribute("messageType"));

        // Forward to the student_enrollments.jsp page
        RequestDispatcher dispatcher = request.getRequestDispatcher("student_enrollments.jsp");
        dispatcher.forward(request, response);
    }
    
}

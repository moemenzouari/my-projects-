package controller;

import java.io.IOException;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Admin;
import model.Course;
import model.Instructor;
import model.User;

/**
 * Servlet implementation class UpdateCourseByInstructorServlet
 */
@WebServlet("/UpdateCourseByInstructorServlet")
public class UpdateCourseByInstructorServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession(false);
    	if (session == null || session.getAttribute("password") == null || session.getAttribute("email") == null) {
            // Redirect to login page if no session or user is found
            response.sendRedirect("login.jsp");
            return;
        }
		
    	String email=(String)session.getAttribute("email");
    	String password=(String)session.getAttribute("password");
    	
        int courseId = Integer.parseInt(request.getParameter("courseId"));
        String courseName = request.getParameter("courseName");
        String category = request.getParameter("category");
        int seats = Integer.parseInt(request.getParameter("seats"));
        Date courseDate = Date.valueOf(request.getParameter("courseDate"));
        String description = request.getParameter("description");
        ResultSet rs=User.userByEmail(email);
    	Instructor instructor=null;
    	try {
			if(rs.next()) {
				instructor = new Instructor(rs.getInt("userId"),rs.getString("email"),rs.getString("password"),rs.getString("username"),rs.getInt("phonenumber"),rs.getString("adress"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        // Update the course in the database
          
    	
    	int res = instructor.updateCourse(courseId,courseName, category, seats, courseDate, description, instructor);
    	if (res==1) {
            // Set success message
            request.setAttribute("message", "Course updated successfully!");
            request.setAttribute("messageType", "success");
        } else {
            // Set error message
            request.setAttribute("message", "Failed to update course.");
            request.setAttribute("messageType", "error");
        }

        // Forward to the course list page
        RequestDispatcher dispatcher = request.getRequestDispatcher("InstructorHomeServlet");
        dispatcher.forward(request, response);
        
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	HttpSession session=request.getSession(false);
    	if (session == null || session.getAttribute("password") == null || session.getAttribute("email") == null) {
            // Redirect to login page if no session or user is found
            response.sendRedirect("login.jsp");
            return;
        }
		
    	String email=(String)session.getAttribute("email");
    	String password=(String)session.getAttribute("password");
    	ResultSet rs=User.userByEmail(email);
    	Instructor instructor=null;
    	try {
			if(rs.next()) {
				instructor = new Instructor(rs.getInt("userId"),rs.getString("email"),rs.getString("password"),rs.getString("username"),rs.getInt("phoneNumber"),rs.getString("adress"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        int courseId = Integer.parseInt(request.getParameter("courseId"));

        // Fetch the course details from the database
        ResultSet rs2= Admin.courseById(courseId);
        try {
			if(rs2.next()) {
				
			    
		    	Course course=new Course(rs2.getInt("courseId"),rs2.getString("courseName"),rs2.getString("category"),rs2.getInt("seats"),instructor,rs2.getDate("courseDate"),rs2.getString("description"));
		    	request.setAttribute("course", course);
		    	
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

        // Set the course as a request attribute
        

        // Forward to the edit_course.jsp page
        RequestDispatcher dispatcher = request.getRequestDispatcher("instructor_edit_course.jsp");
        dispatcher.forward(request, response);
    }

}

package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Student;

/**
 * Servlet implementation class SignUpServlet
 */
@WebServlet("/SignUpServlet")
public class SignUpServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String username = request.getParameter("username");
        int phonenumber = Integer.parseInt(request.getParameter("phonenumber"));
        String address = request.getParameter("address");

        // Create a new user object
        

        // Save the user to the database
        int res=Student.signUp(email, password, username, phonenumber, address);

        if (res==1) {
            response.sendRedirect("StudentHomeServlet");
        } else {
            response.sendRedirect("signup.jsp?error=true");
        }
    }
}

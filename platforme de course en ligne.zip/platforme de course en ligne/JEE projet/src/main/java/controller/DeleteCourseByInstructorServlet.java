package controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Admin;
import model.Instructor;
import model.User;

/**
 * Servlet implementation class DeleteCourseByInstrructorServlet
 */
@WebServlet("/DeleteCourseByInstructorServlet")
public class DeleteCourseByInstructorServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	HttpSession session=request.getSession(false);
    	if (session == null || session.getAttribute("password") == null || session.getAttribute("email") == null) {
            // Redirect to login page if no session or user is found
            response.sendRedirect("login.jsp");
            return;
        }
		
    	String email=(String)session.getAttribute("email");
    	String password=(String)session.getAttribute("password");
    	ResultSet rs=User.userByEmail(email);
    	Instructor instructor=null;
    	try {
			if(rs.next()) {
				instructor = new Instructor(rs.getInt("userId"),rs.getString("email"),rs.getString("password"),rs.getString("username"),rs.getInt("phoneNumber"),rs.getString("adress"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
        int courseId = Integer.parseInt(request.getParameter("courseId"));

        // Delete the course from the database
        int res = instructor.deleteCourse(courseId);

        if (res==1) {
            response.sendRedirect("InstructorHomeServlet");
        } else {
            response.sendRedirect("InstructorHomeServlet");
        }
    }

}

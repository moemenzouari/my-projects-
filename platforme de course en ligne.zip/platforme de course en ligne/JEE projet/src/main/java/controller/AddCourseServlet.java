package controller;

import java.io.IOException;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Admin;
import model.Instructor;

/**
 * Servlet implementation class AddCourseServlet
 */
@WebServlet("/AddCourseServlet")
public class AddCourseServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession(false);
    	if (session == null || session.getAttribute("password") == null || session.getAttribute("email") == null) {
            // Redirect to login page if no session or user is found
            response.sendRedirect("login.jsp");
            return;
        }
    	String email=(String)session.getAttribute("email");
    	String password=(String)session.getAttribute("password");
    	Admin admin = new Admin(email,password);
        String courseName = request.getParameter("courseName");
        String category = request.getParameter("category");
        int seats = Integer.parseInt(request.getParameter("seats"));
        int instructorId = Integer.parseInt(request.getParameter("instructorId"));
        Date courseDate = Date.valueOf(request.getParameter("courseDate"));
        String description = request.getParameter("description"); 
        Date currentDate = new Date(System.currentTimeMillis());
        if (courseDate.before(currentDate)) {
            request.setAttribute("message", "The course date must be greater than today's date.");
            request.setAttribute("messageType", "error");
            RequestDispatcher dispatcher = request.getRequestDispatcher("admin_add_course.jsp");
            dispatcher.forward(request, response);
            return;
        }
        if (seats>30) {
        	request.setAttribute("message", "The maximum number of seats is 30 ");
            request.setAttribute("messageType", "error");
            RequestDispatcher dispatcher = request.getRequestDispatcher("admin_add_course.jsp");
            dispatcher.forward(request, response);
            return;
        }
        try {
            ResultSet rs= Admin.instructorById(instructorId);
            if(rs.next()) {
            	Instructor instructor = new Instructor(rs.getInt("userId"),rs.getString("email"),rs.getString("password"),rs.getString("username"),rs.getInt("phoneNumber"),rs.getString("adress"));
            	int res = admin.addCourse(courseName, category, seats, courseDate, description, instructor);
            	if (res==1) {
                    // Set success message
                    request.setAttribute("message", "Course added successfully!");
                    request.setAttribute("messageType", "success");
                } else {
                    // Set error message
                    request.setAttribute("message", "Failed to add course.");
                    request.setAttribute("messageType", "error");
                }

                // Forward to the course list page
                RequestDispatcher dispatcher = request.getRequestDispatcher("AllCoursesList");
                dispatcher.forward(request, response);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }


        
    }

}

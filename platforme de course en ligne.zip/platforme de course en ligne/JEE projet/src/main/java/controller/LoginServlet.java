package controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.User;

/**
 * Servlet implementation class loginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        // Validate credentials
        ResultSet rs=User.login(email, password);
        

        try {
			if (rs.next()) {
			    HttpSession session = request.getSession();
			    session.setAttribute("password",password );
			    session.setAttribute("email", email);
			    if(rs.getString("role").equals("student")) {
			    	response.sendRedirect("StudentHomeServlet");
			    }
			    else if(rs.getString("role").equals("instructor")) {
			    	response.sendRedirect("InstructorHomeServlet");
			    }
			    else if(rs.getString("role").equals("admin")) {
			    	response.sendRedirect("admin_home.jsp");
			    }
			} else {
			    response.sendRedirect("login.jsp?error=true");
			}
		} catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}

package controller;

import java.io.IOException;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Course;
import model.Instructor;
import model.User;

/**
 * Servlet implementation class AllInstructorsListServlet
 */
@WebServlet("/InstructorHomeServlet")
public class InstructorHomeServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Fetch all courses from the database
    	HttpSession session=request.getSession(false);
    	if (session == null || session.getAttribute("password") == null || session.getAttribute("email") == null) {
            // Redirect to login page if no session or user is found
            response.sendRedirect("login.jsp");
            return;
        }
    	String email=(String)session.getAttribute("email");
    	String password=(String)session.getAttribute("password");
    	ResultSet rs=User.userByEmail(email);
    	Instructor instructor=null;
    	try {
			if(rs.next()) {
				instructor = new Instructor(rs.getInt("userId"),rs.getString("email"),rs.getString("password"),rs.getString("username"),rs.getInt("phonenumber"),rs.getString("adress"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        ArrayList<Course> courses=new ArrayList<Course>() ;
        ResultSet rs2= instructor.listInstructorCourses();
        try {
			while(rs2.next()) {
				Date courseDate=rs2.getDate("courseDate");
				courses.add(new Course(rs2.getInt("courseId"),rs2.getString("courseName"),rs2.getString("category"),rs2.getInt("seats"),instructor,courseDate,rs2.getString("description")));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        // Set the courses as a request attribute
        request.setAttribute("courses", courses);

        // Forward to the admin_courses.jsp page
        RequestDispatcher dispatcher = request.getRequestDispatcher("instructor_home.jsp");
        dispatcher.forward(request, response);
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Fetch all courses from the database
    	HttpSession session=request.getSession(false);
    	if (session == null || session.getAttribute("password") == null || session.getAttribute("email") == null) {
            // Redirect to login page if no session or user is found
            response.sendRedirect("login.jsp");
            return;
        }
    	String email=(String)session.getAttribute("email");
    	String password=(String)session.getAttribute("password");
    	ResultSet rs=User.userByEmail(email);
    	Instructor instructor=null;
    	try {
			if(rs.next()) {
				instructor = new Instructor(rs.getInt("userId"),rs.getString("email"),rs.getString("password"),rs.getString("username"),rs.getInt("phonenumber"),rs.getString("adress"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        ArrayList<Course> courses=new ArrayList<Course>() ;
        ResultSet rs2= instructor.listInstructorCourses();
        try {
			while(rs2.next()) {
				Date courseDate=rs2.getDate("courseDate");
				courses.add(new Course(rs2.getInt("courseId"),rs2.getString("courseName"),rs2.getString("category"),rs2.getInt("seats"),instructor,courseDate,rs2.getString("description")));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        // Set the courses as a request attribute
        request.setAttribute("message", request.getAttribute("message"));
        request.setAttribute("messageType", request.getAttribute("messageType"));
        request.setAttribute("courses", courses);

        // Forward to the admin_courses.jsp page
        RequestDispatcher dispatcher = request.getRequestDispatcher("instructor_home.jsp");
        dispatcher.forward(request, response);
    }
}

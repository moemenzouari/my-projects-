package controller;

import java.io.IOException;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Admin;
import model.Course;
import model.Instructor;
import model.Student;
import model.User;

/**
 * Servlet implementation class StudentHomeServlet
 */
@WebServlet("/StudentHomeServlet")
public class StudentHomeServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	HttpSession session=request.getSession(false);
    	if (session == null || session.getAttribute("password") == null || session.getAttribute("email") == null) {
            // Redirect to login page if no session or user is found
            response.sendRedirect("login.jsp");
            return;
        }
    	String email=(String)session.getAttribute("email");
    	String password=(String)session.getAttribute("password");
    	ResultSet rs=User.userByEmail(email);
    	Student student=null;
    	try {
			if(rs.next()) {
				student = new Student(rs.getInt("userId"),rs.getString("email"),rs.getString("password"),rs.getString("username"),rs.getInt("phoneNumber"),rs.getString("adress"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        ArrayList<Course> courses=new ArrayList<Course>() ;
        ResultSet rs2= student.availableCourses();
        try {
			while(rs2.next()) {
				Date courseDate=rs2.getDate("courseDate");
				ResultSet rs3= Admin.instructorById(rs2.getInt("instructorId"));
				if(rs3.next()) {
					Instructor instructor = new Instructor(rs3.getInt("userId"),rs3.getString("email"),rs3.getString("password"),rs3.getString("username"),rs3.getInt("phonenumber"),rs3.getString("adress"));
					courses.add(new Course(rs2.getInt("courseId"),rs2.getString("courseName"),rs2.getString("category"),rs2.getInt("seats"),instructor,courseDate,rs2.getString("description")));
				}
			}
			System.out.println(courses);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        // Set the courses as a request attribute
        request.setAttribute("courses", courses);

        // Forward to the admin_courses.jsp page
        RequestDispatcher dispatcher = request.getRequestDispatcher("student_home.jsp");
        dispatcher.forward(request, response);
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	HttpSession session=request.getSession(false);
    	if (session == null || session.getAttribute("password") == null || session.getAttribute("email") == null) {
            // Redirect to login page if no session or user is found
            response.sendRedirect("login.jsp");
            return;
        }
    	String email=(String)session.getAttribute("email");
    	String password=(String)session.getAttribute("password");
    	ResultSet rs=User.userByEmail(email);
    	Student student=null;
    	try {
			if(rs.next()) {
				student = new Student(rs.getInt("userId"),rs.getString("email"),rs.getString("password"),rs.getString("username"),rs.getInt("phoneNumber"),rs.getString("adress"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        ArrayList<Course> courses=new ArrayList<Course>() ;
        ResultSet rs2= student.availableCourses();
        try {
			while(rs2.next()) {
				Date courseDate=rs2.getDate("courseDate");
				ResultSet rs3= Admin.instructorById(rs2.getInt("instructorId"));
				if(rs3.next()) {
					Instructor instructor = new Instructor(rs3.getInt("userId"),rs3.getString("email"),rs3.getString("password"),rs3.getString("username"),rs3.getInt("phonenumber"),rs3.getString("adress"));
					Course course = new Course(rs2.getInt("courseId"),rs2.getString("courseName"),rs2.getString("category"),rs2.getInt("seats"),instructor,courseDate,rs2.getString("description"));
					if(course.availableSeats()>0) {
						courses.add(course);
					}
					
				}
			}
			System.out.println(courses);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        // Set the courses as a request attribute
        request.setAttribute("message", request.getAttribute("message"));
        request.setAttribute("messageType", request.getAttribute("messageType"));
        request.setAttribute("courses", courses);

        // Forward to the admin_courses.jsp page
        RequestDispatcher dispatcher = request.getRequestDispatcher("student_home.jsp");
        dispatcher.forward(request, response);
    }
}

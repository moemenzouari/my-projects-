<%@ page import="java.util.ArrayList" %>
<%@ page import="model.Course" %>
<%
    ArrayList<Course> enrollments = (ArrayList<Course>) request.getAttribute("enrollments");
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Enrollments</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="header">
        <h1>Online Courses</h1>
        <div class="user-info">
            <span>Welcome, Student</span>
            <form action="LogoutServlet" method="POST" style="display: inline;">
                <button type="submit" class="logout-btn">Logout</button>
            </form>
        </div>
    </div>
    <div class="container">
    	<%
		    String message = (String) request.getAttribute("message");
		    String messageType = (String) request.getAttribute("messageType");
		%>
		
		<% if (message != null && messageType != null) { %>
		    <div class="message <%= messageType %>">
		        <%= message %>
		    </div>
		<% } %>
        <h2>My Enrollments</h2>
        <table>
            <thead>
                <tr>
                    <th>Course Name</th>
                    <th>Category</th>
                    <th>Instructor</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <% if (enrollments != null && !enrollments.isEmpty()) { %>
                    <% for (Course enrollment : enrollments) { %>
                        <tr>
                            <td><%= enrollment.getCourseName() %></td>
                            <td><%= enrollment.getCategory() %></td>
                            <td><%= enrollment.getInstructor().getUsername() %></td>
                            <td><%= enrollment.getCourseDate() %></td>
                            <td>
                                <a href="CancelEnrollmentServlet?courseId=<%= enrollment.getCourseId() %>" onclick="return confirm('Are you sure you want to cancel this enrollment?')">Cancel</a>
                            </td>
                        </tr>
                    <% } %>
                <% } else { %>
                    <tr>
                        <td colspan="5">No enrollments available.</td>
                    </tr>
                <% } %>
            </tbody>
        </table>
    </div>
</body>
</html>
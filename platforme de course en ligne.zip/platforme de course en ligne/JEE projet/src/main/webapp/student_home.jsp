<%@ page import="model.User" %>
<%@ page import="java.util.ArrayList" %>
<%@ page import="model.Course" %>
<%
    
	ArrayList<Course> courses = (ArrayList<Course>) request.getAttribute("courses");
%>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student - Courses</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="header">
        <h1>Online Courses</h1>
        <div class="user-info">
            <span>Welcome, Student</span>
            <form action="StudentEnrollmentsServlet" method="POST" style="display: inline;">
                <button type="submit" class="enrollments-btn" style="background-color: green; color: white; padding: 8px 16px;">my enrollments</button>
            </form>
            <form action="LogoutServlet" method="POST" style="display: inline;">
                <button type="submit" class="logout-btn" >Logout</button>
            </form>
            
        </div>
    </div>

    <div class="container">
    <%
		    String message = (String) request.getAttribute("message");
		    String messageType = (String) request.getAttribute("messageType");
		%>
		
		<% if (message != null && messageType != null) { %>
		    <div class="message <%= messageType %>">
		        <%= message %>
		    </div>
		<% } %>
        <h2>Available Courses</h2>
        
        <div class="course-grid">
            <% if (courses != null && !courses.isEmpty()) { %>
                <% for (Course course : courses) { %>
                    <div class="course-card">
                        <img src="https://images.pexels.com/photos/4145190/pexels-photo-4145190.jpeg?auto=compress&cs=tinysrgb&w=250" alt="Course Image">
                        <h3><%= course.getCourseName() %></h3>
                        <p><strong>Category:</strong> <%= course.getCategory() %></p>
                        <p><strong>Instructor:</strong> <%= course.getInstructor().getUsername() %></p>
                        <p><strong>Date:</strong> <%= course.getCourseDate() %></p>
                        <p><strong>Seats Available:</strong> <%= course.availableSeats() %></p>
                        <a href="EnrollServlet?courseId=<%= course.getCourseId() %>" class="enroll-btn">Enroll</a>
                    </div>
                <% } %>
            <% } else { %>
                <p>No courses available.</p>
            <% } %>
        </div>
    </div>
</body>
</html>
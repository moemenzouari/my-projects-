<%@ page import="model.Instructor" %>
<%@ page import="java.sql.ResultSet" %>
<%
    ResultSet rs = (ResultSet) request.getAttribute("instructorData");
    if (rs != null && rs.next()) {
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Instructor</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="header">
        <h1>Online Courses</h1>
        <div class="user-info">
            <span>Welcome, Admin</span>
            <form action="LogoutServlet" method="POST" style="display: inline;">
                <button type="submit" class="logout-btn">Logout</button>
            </form>
        </div>
    </div>

    <!-- Display Success/Error Message -->
    <% 
        String message = (String) request.getAttribute("message");
        String messageType = (String) request.getAttribute("messageType");
        if (message != null && messageType != null) { 
    %>
        <div class="message <%= messageType %>">
            <%= message %>
        </div>
    <% } %>

    <div class="container">
        <h2>Edit Instructor</h2>
        <form action="UpdateInstructorServlet" method="POST">
            <input type="hidden" name="instructorId" value="<%= rs.getInt("userId") %>">

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<%= rs.getString("email") %>" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" value="<%= rs.getString("password") %>" required>

            <label for="username">Username:</label>
            <input type="text" id="username" name="username" value="<%= rs.getString("username") %>" required>

            <label for="phoneNumber">Phone Number:</label>
            <input type="number" id="phoneNumber" name="phoneNumber" value="<%= rs.getInt("phonenumber") %>" required>

            <label for="address">Address:</label>
            <input type="text" id="address" name="address" value="<%= rs.getString("adress") %>" required>

            <button type="submit">Save Changes</button>
        </form>
    </div>
</body>
</html>
<%
    } else {
        response.sendRedirect("AllInstructorsListServlet");
    }
%>
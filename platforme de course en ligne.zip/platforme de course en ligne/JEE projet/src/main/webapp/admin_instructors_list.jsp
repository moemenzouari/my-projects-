<%@ page import="java.util.ArrayList" %>
<%@ page import="model.Instructor" %>
<%
    ArrayList<Instructor> instructors = (ArrayList<Instructor>)request.getAttribute("instructors");
	String test=(String)request.getAttribute("test");
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Instructors</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="header">
        <h1>Online Courses</h1>
        <div class="user-info">
            <span>Welcome, Admin</span>
            <form action="LogoutServlet" method="POST" style="display: inline;">
                <button type="submit" class="logout-btn">Logout</button>
            </form>
        </div>
    </div>
    <div class="container">
        <h2>Instructors Management</h2>
        <a href="admin_add_instructor.jsp" class="button">Add New Instructor</a>
        <table>
            <thead>
                <tr>
                    <th>User ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Phone Number</th>
                    <th>Address</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <% if (instructors != null && !instructors.isEmpty()) { %>
                    <% for (Instructor instructor : instructors) { %>
                        <tr>
                            <td><%= instructor.getUserId() %></td>
                            <td><%= instructor.getUsername() %></td>
                            <td><%= instructor.getEmail() %></td>
                            <td><%= instructor.getPhoneNumber() %></td>
                            <td><%= instructor.getAdress() %></td>
                            <td>
                                <a href="UpdateInstructorServlet?userId=<%= instructor.getUserId() %>">Edit</a>
                                <a href="DeleteInstructorServlet?userId=<%= instructor.getUserId() %>" onclick="return confirm('Are you sure you want to delete this instructor?')">Delete</a>
                            </td>
                        </tr>
                    <% } %>
                <% } else { %>
                    <tr>
                        <td colspan="6">No instructors available.</td>
                    </tr>
                <% } %>
            </tbody>
        </table>
    </div>
</body>
</html>
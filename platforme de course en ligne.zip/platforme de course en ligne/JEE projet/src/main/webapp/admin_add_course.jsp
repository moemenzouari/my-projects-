<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Course</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="header">
        <h1>Online Courses</h1>
        <div class="user-info">
            <span>Welcome, Admin</span>
            <form action="LogoutServlet" method="POST" style="display: inline;">
                <button type="submit" class="logout-btn">Logout</button>
            </form>
        </div>
    </div>
    <div class="container">
        <h2>Add New Course</h2>
        <!-- Display Success/Error Message -->
        <% 
            String message = (String) request.getAttribute("message");
            String messageType = (String) request.getAttribute("messageType");
            if (message != null && messageType != null) { 
        %>
            <div class="message <%= messageType %>">
                <%= message %>
            </div>
        <% } %>
        <form action="AddCourseServlet" method="POST">
            <label for="courseName">Course Name:</label>
            <input type="text" id="courseName" name="courseName" required>

            <label for="category">Category:</label>
            <input type="text" id="category" name="category" required>

            <label for="seats">Seats :</label>
            <input type="number" id="seats" name="seats" min="1" required>

            <label for="courseDate">Course Date:</label>
            <input type="date" id="courseDate" name="courseDate" required>

            <label for="description">Description:</label>
            <textarea id="description" name="description"></textarea>

            <label for="instructorId">Instructor ID:</label>
            <input type="number" id="instructorId" name="instructorId" required>

            <button type="submit">Add Course</button>
        </form>
    </div>
</body>
</html>
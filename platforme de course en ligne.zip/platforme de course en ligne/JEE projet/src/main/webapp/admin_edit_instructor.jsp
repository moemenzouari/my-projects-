<%@ page import="model.Instructor" %>
<%
    Instructor instructor = (Instructor) request.getAttribute("instructor");
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Instructor</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="header">
        <h1>Online Courses</h1>
        <div class="user-info">
            <span>Welcome, Admin</span>
            <form action="LogoutServlet" method="POST" style="display: inline;">
                <button type="submit" class="logout-btn">Logout</button>
            </form>
        </div>
    </div>
    <div class="container">
        <h2>Edit Instructor</h2>
        <form action="EditInstructorServlet" method="POST">
            <input type="hidden" name="instructorId" value="<%= instructor.getUserId() %>">

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<%= instructor.getEmail() %>" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" value="<%= instructor.getPassword() %>" required>

            <label for="username">Username:</label>
            <input type="text" id="username" name="username" value="<%= instructor.getUsername() %>" required>

            <label for="phoneNumber">Phone Number:</label>
            <input type="number" id="phoneNumber" name="phoneNumber" value="<%= instructor.getPhoneNumber() %>" required>

            <label for="address">Address:</label>
            <input type="text" id="address" name="address" value="<%= instructor.getAdress() %>">

            <button type="submit">Save Changes</button>
        </form>
    </div>
</body>
</html>
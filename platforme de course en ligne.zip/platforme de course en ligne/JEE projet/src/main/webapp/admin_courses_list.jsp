<%@ page import="java.util.ArrayList" %>
<%@ page import="model.Course" %>
<% ArrayList<Course> courses = (ArrayList<Course>) request.getAttribute("courses");
	
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Courses</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <div class="header">
        <h1>Online Courses</h1>
        <div class="user-info">
            <span>Welcome, Admin</span>
            <form action="LogoutServlet" method="POST" style="display: inline;">
                <button type="submit" class="logout-btn">Logout</button>
            </form>
        </div>
    </div>
    <div class="container">
    	<%
		    String message = (String) request.getAttribute("message");
		    String messageType = (String) request.getAttribute("messageType");
		%>
		
		<% if (message != null && messageType != null) { %>
		    <div class="message <%= messageType %>">
		        <%= message %>
		    </div>
		<% } %>
        <h2>Courses Management</h2>
        <a href="admin_add_course.jsp" class="button">Add New Course</a>
        <table>
            <thead>
                <tr>
                    <th>Course ID</th>
                    <th>Course Name</th>
                    <th>Category</th>
                    <th>Instructor</th>
                    <th>Seats</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <% if (courses != null && !courses.isEmpty()) { %>
                    <% for (Course course : courses) { %>
                        <tr>
                            <td><%= course.getCourseId() %></td>
                            <td><%= course.getCourseName() %></td>
                            <td><%= course.getCategory() %></td>
                            <td><%= course.getInstructor().getUsername()%></td>
                            <td><%= course.getSeats() %></td>
                            <td><%= course.getCourseDate() %></td>
                            <td>
                                <a href="UpdateCourseServlet?courseId=<%= course.getCourseId() %>">Edit</a>
                                <a href="DeleteCourseServlet?courseId=<%= course.getCourseId() %>" onclick="return confirm('Are you sure you want to delete this course?')">Delete</a>
                            </td>
                        </tr>
                    <% } %>
                <% } else { %>
                    <tr>
                        <td colspan="7">No courses available.</td>
                    </tr>
                <% } %>
            </tbody>
        </table>
    </div>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Home</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Welcome, Admin!</h2>
        <h3>Manage Content</h3>
        <ul>
            <li><a href="AllCoursesList">Manage Courses</a></li>
            <li><a href="AllInstructorsListServlet">Manage Instructors</a></li>
        </ul>
    </div>
</body>
</html>
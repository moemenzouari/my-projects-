<%@ page import="model.Course" %>
<%
    Course course = (Course) request.getAttribute("course");
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Course</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="header">
        <h1>Online Courses</h1>
        <div class="user-info">
            <span>Welcome, Admin</span>
            <form action="LogoutServlet" method="POST" style="display: inline;">
                <button type="submit" class="logout-btn">Logout</button>
            </form>
        </div>
    </div>
    <div class="container">
        <h2>Edit Course</h2>
        <form action="UpdateCourseServlet" method="POST">
            <input type="hidden" name="courseId" value="<%= course.getCourseId() %>">

            <label for="courseName">Course Name:</label>
            <input type="text" id="courseName" name="courseName" value="<%= course.getCourseName() %>" required>

            <label for="category">Category:</label>
            <input type="text" id="category" name="category" value="<%= course.getCategory() %>" required>

            <label for="seats">Seats Available:</label>
            <input type="number" id="seats" name="seats" value="<%= course.getSeats() %>" required>

            <label for="courseDate">Course Date:</label>
            <input type="date" id="courseDate" name="courseDate" value="<%= course.getCourseDate() %>" required>

            <label for="description">Description:</label>
            <textarea id="description" name="description"><%= course.getDescription() %></textarea>

            <label for="instructorId">Instructor ID:</label>
            <input type="number" id="instructorId" name="instructorId" value="<%= course.getInstructor().getUserId() %>" required>

            <button type="submit">Save Changes</button>
        </form>
    </div>
</body>
</html>
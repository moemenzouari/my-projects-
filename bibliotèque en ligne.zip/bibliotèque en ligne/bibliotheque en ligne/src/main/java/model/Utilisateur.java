package model;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import controller.ConnectToDataBase;
public class Utilisateur {
	private String login;
	private String motDePasse;
	public Utilisateur(String login,String motDePasse) {
		this.login=login;
		this.motDePasse=motDePasse;
	}
	public ResultSet livresDisponibles() throws ClassNotFoundException {
		Connection c = ConnectToDataBase.connect();
		try {
			Statement st=c.createStatement();
			ResultSet rs=st.executeQuery("select * from livre");
			return rs;
		}
		catch(SQLException e) {
			System.out.println(e.getStackTrace());
			return null;
		}
		
	}
	public ResultSet livreParAuteur(String auteur) {
		Connection c = ConnectToDataBase.connect();
		try {
			Statement st=c.createStatement();
			String sql="select * from livre where auteur='"+auteur+"'";
			ResultSet rs=st.executeQuery(sql);
			return rs;
		}
		catch(SQLException e) {
			System.out.println(e.getStackTrace());
			return null;
		}
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getMotDePasse() {
		return motDePasse;
	}
	public void setMotDePasse(String motDePasse) {
		this.motDePasse = motDePasse;
	}
}

package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import controller.ConnectToDataBase;

public class Admin extends Utilisateur{
	public Admin(String login , String motDePasse) {
		super(login,motDePasse);
	}
	public static boolean verifierMotDePasse(String login ,String motDePasse) {
		Connection c=ConnectToDataBase.connect();
		PreparedStatement ps;
		try {
			ps = c.prepareStatement("select * from admin where login=?");
			ps.setString(1, login);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				if(rs.getString("motdepasse").equals(motDePasse)) {
					return true;
				}
				else {
					return false;
				}
			}
			return false;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public void ajouterLivre(String isbn,String auteur,String titre,int annee,int prix) {
		Connection c=ConnectToDataBase.connect();
		PreparedStatement ps;
		try {
			ps=c.prepareStatement("insert into livre values(?,?,?,?,?)");
			ps.setString(1, isbn);
			ps.setString(2, auteur);
			ps.setString(3, titre);
			ps.setInt(4, annee);
			ps.setInt(5, prix);
			int nb=ps.executeUpdate();
			if(nb==1)
				System.out.println("livre ajoute avec succes");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void supprimerLivre(String isbn) {
		Connection c=ConnectToDataBase.connect();
		PreparedStatement ps;
		try {
			ps=c.prepareStatement("delete from livre where isbn=?");
			ps.setString(1, isbn);
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

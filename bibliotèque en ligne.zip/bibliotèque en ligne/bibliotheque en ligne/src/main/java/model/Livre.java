package model;

public class Livre {
	private String isbn;
	private String auteur;
	private String titre;
	private int annee;
	private int prix;
	public Livre(String isbn,String auteur,String titre,int annee,int prix) {
		this.isbn=isbn;
		this.auteur=auteur;
		this.titre=titre;
		this.annee=annee;
		this.prix=prix;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public String getAuteur() {
		return auteur;
	}
	public void setAuteur(String auteur) {
		this.auteur = auteur;
	}
	public String getTitre() {
		return titre;
	}
	public void setTitre(String titre) {
		this.titre = titre;
	}
	public int getAnnee() {
		return annee;
	}
	public void setAnnee(int annee) {
		this.annee = annee;
	}
	public int getPrix() {
		return prix;
	}
	public void setPrix(int prix) {
		this.prix = prix;
	}
}

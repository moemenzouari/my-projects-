package model;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import controller.ConnectToDataBase;
public class Client extends Utilisateur{
	public Client(String login,String motDePasse) {
		super(login,motDePasse);
	}
	public static boolean checkUser(String login,String motDePasse)  {
		Connection c = ConnectToDataBase.connect();
		String query = "select * from client where login=? and motdepasse=? ";
		try {
			PreparedStatement ps;
			ps = c.prepareStatement(query);
			ps.setString(1, login);
			ps.setString(2, motDePasse);
			ResultSet rs=ps.executeQuery();
			rs.next();
			String mdp=rs.getString("motdepasse");
			if(mdp.equals(motDePasse)){
				c.close();
				return true;
			}
			else {
				c.close();
				return false;
			}
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		
		
	}
	public void commanderLivre(String isbn) {
		Connection c=ConnectToDataBase.connect();
		PreparedStatement ps;
		try {
			ps = c.prepareStatement("select * from livre where isbn=?");
			ps.setString(1,isbn);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				Statement st=c.createStatement();
				String query="select livres_commande from client where login='"+getLogin()+"'";
				ResultSet res=st.executeQuery(query);
				if(res.next()) {
					String lc=res.getString("livres_commande")+" "+rs.getString("isbn") ;
					Statement st2=c.createStatement();
					String sql ="update client set livres_commande='"+lc+"' where login='"+getLogin()+"'";
					st2.executeUpdate(sql);
					System.out.println("le livre est ajoute au panier avec succes");
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
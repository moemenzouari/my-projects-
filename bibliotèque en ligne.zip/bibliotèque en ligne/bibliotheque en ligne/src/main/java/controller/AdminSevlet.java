package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Admin;
import model.Client;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Servlet implementation class AdminSevlet
 */
@WebServlet({"/afficherListeLivresAdmin","/chercherLivreParAuteurAdmin","/ajouterLivre","/supprimerLivre"})
public class AdminSevlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminSevlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getServletPath();
		if(action.equals("/afficherListeLivresAdmin"))
			try {
				afficherListeLivresAdmin(request,response);
			} catch (ClassNotFoundException | ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		if(action.equals("/supprimerLivre"))
			try {
				supprimerLivre(request,response);
			} catch (ClassNotFoundException | ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		if(action.equals("/chercherLivreParAuteurAdmin"))
			try {
				chercherLivreParAuteurAdmin(request,response);
			} catch (ClassNotFoundException | ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getServletPath();
		
		
		if(action.equals("/ajouterLivre"))
			try {
				ajouterLivre(request,response);
			} catch (ClassNotFoundException | ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	public void afficherListeLivresAdmin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException, ClassNotFoundException{
    	String login=(String) request.getSession().getAttribute("nomUtilisateur");
    	String password=(String) request.getSession().getAttribute("motDePasse");
    	Admin a1=new Admin(login,password);
		ResultSet rs=a1.livresDisponibles();
		request.getRequestDispatcher("AdminHome.jsp").include(request, response);
		response.getWriter().println("<table class=\"table\">\r\n"
				+ "  <thead>\r\n"
				+ "    <tr>\r\n"
				+ "      <th scope=\"col\">isbn</th>\r\n"
				+ "      <th scope=\"col\">auteur</th>\r\n"
				+ "      <th scope=\"col\">titre</th>\r\n"
				+ "      <th scope=\"col\">annee</th>\r\n"
				+ "	 	 <th scope=\"col\">prix</th>\r\n"
				+ "	 	 <th scope=\"col\">actions</th>\r\n"
				+ "    </tr>\r\n"
				+ "  </thead>\r\n"
				+ "<tbody>");
		
		while(rs.next()) {
			response.getWriter().println("<tr>\r\n"
					+ "      <th scope=\"row\">"+rs.getString(1)+"</th>\r\n"
					+ "      <td>"+rs.getString(2)+"</td>\r\n"
					+ "      <td>"+rs.getString(3)+"</td>\r\n"
					+ "      <td>"+rs.getString(4)+"</td>\r\n"
					+ "      <td>"+rs.getString(5)+"</td>\r\n"
					+ "      <td><a class=\"btn btn-primary\" href=\"supprimerLivre?isbnASupprimer="+rs.getString(1)+" role=\"button\">supprimer</a></td>\r\n"
					+ "    </tr>");
		}
		response.getWriter().println("</tbody>"
				+ "</table>");
			
    }
	public void chercherLivreParAuteurAdmin(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, ServletException, IOException, SQLException {
		// TODO Auto-generated method stub
		String login=(String) request.getSession().getAttribute("nomUtilisateur");
    	String password=(String) request.getSession().getAttribute("motDePasse");
    	Admin a1=new Admin(login,password);
		ResultSet rs=a1.livreParAuteur(request.getParameter("auteur"));
		request.getRequestDispatcher("AdminHome.jsp").include(request, response);
		if(!rs.next()) {
			response.getWriter().println("pas de livres disponibles par ce nom d'auteur");
		}
		else {
			response.getWriter().println("<table class=\"table\">\r\n"
					+ "  <thead>\r\n"
					+ "    <tr>\r\n"
					+ "      <th scope=\"col\">isbn</th>\r\n"
					+ "      <th scope=\"col\">auteur</th>\r\n"
					+ "      <th scope=\"col\">titre</th>\r\n"
					+ "      <th scope=\"col\">annee</th>\r\n"
					+ "	 	 <th scope=\"col\">prix</th>\r\n"
					+ "	 	 <th scope=\"col\">actions</th>\r\n"
					+ "    </tr>\r\n"
					+ "  </thead>\r\n"
					+ "<tbody>");
			response.getWriter().println("<tr>\r\n"
					+ "      <th scope=\"row\">"+rs.getString(1)+"</th>\r\n"
					+ "      <td>"+rs.getString(2)+"</td>\r\n"
					+ "      <td>"+rs.getString(3)+"</td>\r\n"
					+ "      <td>"+rs.getString(4)+"</td>\r\n"
					+ "      <td>"+rs.getString(5)+"</td>\r\n"
					+ "      <td><a class=\"btn btn-primary\" href=\"supprimerLivre?isbnASupprimer="+rs.getString(1)+" role=\"button\">supprimer</a></td>\r\n"
					+ "    </tr>");
			while(rs.next()) {
				response.getWriter().println("<tr>\r\n"
						+ "      <th scope=\"row\">"+rs.getString(1)+"</th>\r\n"
						+ "      <td>"+rs.getString(2)+"</td>\r\n"
						+ "      <td>"+rs.getString(3)+"</td>\r\n"
						+ "      <td>"+rs.getString(4)+"</td>\r\n"
						+ "      <td>"+rs.getString(5)+"</td>\r\n"
						+ "      <td><a class=\"btn btn-primary\" href='supprimerLivre?isbnASupprimer="+rs.getString(1)+"' role='button'>commander livre</a></td>\r\n"
						+ "    </tr>");
			}
			response.getWriter().println("</tbody>"
					+ "</table>");
		}
	}
	public void ajouterLivre(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, ServletException, IOException, SQLException {
		String isbn =request.getParameter("isbn");
		String auteur =request.getParameter("auteur");
		String titre =request.getParameter("titre");
		int annee = Integer.parseInt(request.getParameter("annee"));
		int prix =Integer.parseInt(request.getParameter("prix"));
		String login=(String)request.getSession().getAttribute("nomUtilisateur");
		String password=(String)request.getSession().getAttribute("motDePasse");
		Admin a1=new Admin(login,password);
		a1.ajouterLivre(isbn, auteur, titre, annee, prix);
		response.getWriter().println("livre ajoute avec succes");
		response.sendRedirect("AdminHome.jsp");
	}
	public void supprimerLivre(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, ServletException, IOException, SQLException {
		String isbn=request.getParameter("isbnASupprimer");
		String login=(String)request.getSession().getAttribute("nomUtilisateur");
		String password=(String)request.getSession().getAttribute("motDePasse");
		Admin a1=new Admin(login,password);
		a1.supprimerLivre(isbn);
		afficherListeLivresAdmin(request,response);
	}
}

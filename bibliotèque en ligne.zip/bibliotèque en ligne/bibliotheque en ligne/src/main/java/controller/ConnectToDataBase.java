package controller;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class ConnectToDataBase {
	public static Connection connect(){
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/bdgestionlivres","root","zouari30042003");
			System.out.println("database connected");
			return c;
		}
		catch(SQLException | ClassNotFoundException e) {
			System.out.println(e.getStackTrace());
			return null;
		}
		
	}
}

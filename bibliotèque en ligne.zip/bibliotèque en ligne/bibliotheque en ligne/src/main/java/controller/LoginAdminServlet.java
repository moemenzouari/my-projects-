package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Admin;
import model.Client;

import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class LoginAdminServlet
 */
@WebServlet("/LoginAdminServlet")
public class LoginAdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginAdminServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String nomUtilisateur=request.getParameter("nomUtilisateur");
		String motDePasse=request.getParameter("motDePasse");
		PrintWriter out= response.getWriter();
		response.setContentType("text/html");
		if(Admin.verifierMotDePasse(nomUtilisateur, motDePasse)) {
			request.getSession().setAttribute("nomUtilisateur", nomUtilisateur);
			request.getSession().setAttribute("motDePasse",motDePasse );;
			response.sendRedirect("AdminHome.jsp");
		}
		else {
			request.getRequestDispatcher("espaceadmin.html").include(request, response);
			out.println("veuiller verifier vos donnees");
		}
	}

}

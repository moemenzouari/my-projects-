package controller;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Client;

/**
 * Servlet implementation class ClientServlet
 */
@WebServlet({"/afficherListeLivres","/chercherLivreParAuteur","/commanderLivre"})
public class ClientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ClientServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    public void afficherListeLivres(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException, ClassNotFoundException{
    	String login=(String) request.getSession().getAttribute("nomUtilisateur");
    	String password=(String) request.getSession().getAttribute("motDePasse");
    	Client c1=new Client(login,password);
		ResultSet rs=c1.livresDisponibles();
		request.getRequestDispatcher("home.jsp").include(request, response);
		response.getWriter().println("<table class=\"table\">\r\n"
				+ "  <thead>\r\n"
				+ "    <tr>\r\n"
				+ "      <th scope=\"col\">isbn</th>\r\n"
				+ "      <th scope=\"col\">auteur</th>\r\n"
				+ "      <th scope=\"col\">titre</th>\r\n"
				+ "      <th scope=\"col\">annee</th>\r\n"
				+ "	 	 <th scope=\"col\">prix</th>\r\n"
				+ "	 	 <th scope=\"col\">action</th>\r\n"
				+ "    </tr>\r\n"
				+ "  </thead>\r\n"
				+ "<tbody>");
		
		while(rs.next()) {
			response.getWriter().println("<tr>\r\n"
					+ "      <th scope=\"row\">"+rs.getString(1)+"</th>\r\n"
					+ "      <td>"+rs.getString(2)+"</td>\r\n"
					+ "      <td>"+rs.getString(3)+"</td>\r\n"
					+ "      <td>"+rs.getString(4)+"</td>\r\n"
					+ "      <td>"+rs.getString(5)+"</td>\r\n"
					+ "      <td><a class=\"btn btn-primary\" href='commanderLivre?isbn="+rs.getString(1)+"' role=\"button\">commander livre</a></td>\r\n"
					+ "    </tr>");
		}
		response.getWriter().println("</tbody>"
				+ "</table>");
			
    }
    public void chercherLivreParAuteur(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, ServletException, IOException, SQLException {
		// TODO Auto-generated method stub
		String login=(String) request.getSession().getAttribute("nomUtilisateur");
    	String password=(String) request.getSession().getAttribute("motDePasse");
    	Client c1=new Client(login,password);
		ResultSet rs=c1.livreParAuteur(request.getParameter("auteur"));
		request.getRequestDispatcher("home.jsp").include(request, response);
		if(!rs.next()) {
			response.getWriter().println("pas de livres disponibles par ce nom d'auteur");
		}
		else {
			response.getWriter().println("<table class=\"table\">\r\n"
					+ "  <thead>\r\n"
					+ "    <tr>\r\n"
					+ "      <th scope=\"col\">isbn</th>\r\n"
					+ "      <th scope=\"col\">auteur</th>\r\n"
					+ "      <th scope=\"col\">titre</th>\r\n"
					+ "      <th scope=\"col\">annee</th>\r\n"
					+ "	 	 <th scope=\"col\">prix</th>\r\n"
					+ "	 	 <th scope=\"col\">action</th>\r\n"
					+ "    </tr>\r\n"
					+ "  </thead>\r\n"
					+ "<tbody>");
			response.getWriter().println("<tr>\r\n"
					+ "      <th scope=\"row\">"+rs.getString(1)+"</th>\r\n"
					+ "      <td>"+rs.getString(2)+"</td>\r\n"
					+ "      <td>"+rs.getString(3)+"</td>\r\n"
					+ "      <td>"+rs.getString(4)+"</td>\r\n"
					+ "      <td>"+rs.getString(5)+"</td>\r\n"
					+ "      <td><a class=\"btn btn-primary\" href=\"commanderLivre?isbn="+rs.getString(1)+" role=\"button\">commander livre</a></td>\r\n"
					+ "    </tr>");
			while(rs.next()) {
				response.getWriter().println("<tr>\r\n"
						+ "      <th scope=\"row\">"+rs.getString(1)+"</th>\r\n"
						+ "      <td>"+rs.getString(2)+"</td>\r\n"
						+ "      <td>"+rs.getString(3)+"</td>\r\n"
						+ "      <td>"+rs.getString(4)+"</td>\r\n"
						+ "      <td>"+rs.getString(5)+"</td>\r\n"
						+ "      <td><a class=\"btn btn-primary\" href='commanderLivre?isbn="+rs.getString(1)+"' role=\"button\">commander livre</a></td>\r\n"
						+ "    </tr>");
			}
			response.getWriter().println("</tbody>"
					+ "</table>");
		}
	}
    public void commanderLivre(HttpServletRequest request, HttpServletResponse response) throws ClassNotFoundException, ServletException, IOException, SQLException {
    	String isbn=request.getParameter("isbn");
    	String login=(String) request.getSession().getAttribute("nomUtilisateur");
    	String password=(String) request.getSession().getAttribute("motDePasse");
    	Client c1=new Client(login,password);
    	c1.commanderLivre(isbn);
    	request.getRequestDispatcher("home.jsp").include(request, response);
    	response.getWriter().println("livre commande avec succes");
    	
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getServletPath();
		/*switch(action){ 
		case "/afficherListeLivres":
			try {
				afficherListeLivres(request,response);
			} catch (ClassNotFoundException | ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/checherLivreParAuteur":
			try {
				chercherLivreParAuteur(request,response);
			} catch (ClassNotFoundException | ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		
		}*/
		if(action.equals("/afficherListeLivres")) {
			try {
				afficherListeLivres(request,response);
			} catch (ClassNotFoundException | ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if(action.equals("/commanderLivre")) {
			try {
				commanderLivre(request,response);
			} catch (ClassNotFoundException | ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String action = request.getServletPath();
		if(action.equals("/chercherLivreParAuteur")) {
			try {
				chercherLivreParAuteur(request,response);
			} catch (ClassNotFoundException | ServletException | IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	
	
}

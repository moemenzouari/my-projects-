package controller;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Client;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginClientServlet")
public class LoginClientServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginClientServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String nomUtilisateur=request.getParameter("nomUtilisateur");
		String motDePasse=request.getParameter("motDePasse");
		PrintWriter out= response.getWriter();
		response.setContentType("text/html");
		if(Client.checkUser(nomUtilisateur, motDePasse)) {
			request.getSession().setAttribute("nomUtilisateur", nomUtilisateur);
			request.getSession().setAttribute("motDePasse",motDePasse );;
			response.sendRedirect("home.jsp");
		}
		else {
			request.getRequestDispatcher("index.html").include(request, response);
			out.println("veuiller verifier vos donnees");
		}
	
		
	}

}

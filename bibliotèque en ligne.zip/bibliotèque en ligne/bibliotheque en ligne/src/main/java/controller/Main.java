package controller;

import java.sql.Connection;

public class Main {

	public static void main(String[] args) throws ClassNotFoundException {
		// TODO Auto-generated method stub
		Connection c=ConnectToDataBase.connect();
	}

}

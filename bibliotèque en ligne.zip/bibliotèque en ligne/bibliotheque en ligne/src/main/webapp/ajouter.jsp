<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<style>
	body{
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		margin-top: 10%;
	}
	form{
		border: 1px solid black;
		margin:10px;
		padding: 25px;
		width: 500px;
		display: flex;
		flex-direction: column;
	}
</style>
<title>Insert title here</title>
</head>
<body>
	<h2>ajout livre</h2>
	<form action="ajouterLivre" method="post">
	  <div class="form-group">
	    <label >isbn</label>
	    <input type="text" class="form-control" aria-describedby="emailHelp" name="isbn">
	  </div>
	  <div class="form-group">
	    <label >auteur</label>
	    <input type="text" class="form-control" aria-describedby="emailHelp"  name="auteur">
	  </div>
	  <div class="form-group">
	    <label >titre</label>
	    <input type="text" class="form-control" aria-describedby="emailHelp"  name="titre">
	  </div>
	  <div class="form-group">
	    <label >annee</label>
	    <input type="number" class="form-control" aria-describedby="emailHelp"  name="annee">
	  </div>
	  <div class="form-group">
	    <label >prix</label>
	    <input type="number" class="form-control" aria-describedby="emailHelp"  name="prix">
	  </div>
	  <button type="submit" class="btn btn-primary">ajouter</button>
	</form>
</body>
</html>
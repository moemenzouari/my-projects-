<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<style>
div{
width:50%;
margin:10px;
}
body{
margin-top:10%;
display: flex;
flex-direction: column;
justify-content: center;
align-items: center;
height: 100%;
font-size:18px;
}
nav{
width:20%;
}

</style>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</head>
<body>
	<a role="button" class="btn btn-primary btn-lg btn-block" href="afficherListeLivresAdmin" >afficher liste de livres disponibles </a><br>
	<a role="button" class="btn btn-primary btn-lg btn-block" href="ajouter.jsp" >ajouter livre </a><br>
	
	<nav class="navbar navbar-light bg-light">
	  <form class="form-inline" action="chercherLivreParAuteurAdmin" method="get">
	  	<label>checher livre par auteur</label>
	    <input class="form-control mr-sm-2" type="search" placeholder="chercher" aria-label="Search" name="auteur">
	    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">chercher</button>
	  </form>
	</nav>
</body>
</html>